# Sagnik Nag — Academic Profile

Responsive academic profile website in the Modern Researcher design.

## Files
- `index.html`: webpage and responsive styling
- `assets/sagnik-nag-portrait.png`: your supplied portrait

## Preview
Open `index.html` in a browser. Keep the `assets` folder beside it.

## Publish using GitHub Pages
1. Sign in to GitHub or create an account.
2. Create a repository (for a personal site, `YOUR-USERNAME.github.io` is a common choice).
3. Upload `index.html` and the `assets` folder, preserving the folder structure.
4. Open repository Settings → Pages and follow the publishing instructions shown there.
5. Wait for the public URL to become available and test it on a phone.
6. Generate the final QR code only after the live URL is verified.

## Before publishing
Review the biography and test the profile links. Your portrait and email will be public on the website. No QR code is included yet because the site has not been published and no public destination URL has been verified.
